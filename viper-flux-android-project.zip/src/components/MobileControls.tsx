import React from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Zap,
} from 'lucide-react';
import { Direction } from '../game/types';

interface MobileControlsProps {
  onDirection: (dir: Direction) => void;
  onBoostChange: (boosting: boolean) => void;
  isBoosting: boolean;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onDirection,
  onBoostChange,
  isBoosting,
}) => {
  const handleDirDown = (dir: Direction) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onDirection(dir);
  };

  return (
    <div className="flex w-full max-w-[460px] items-center justify-between gap-4 px-2 pt-2 pb-1 select-none">
      {/* Tactile Arcade Cross D-Pad */}
      <div className="grid grid-cols-3 grid-rows-3 gap-1.5 w-[150px] h-[150px]">
        <div />
        <button
          type="button"
          aria-label="Move Up"
          onPointerDown={handleDirDown('UP')}
          className="flex items-center justify-center rounded-xl border border-slate-700/80 bg-slate-900/90 text-slate-100 shadow-inner active:scale-95 active:border-emerald-400/70 active:bg-emerald-500/25 active:text-emerald-200 cursor-pointer"
        >
          <ArrowUp className="h-6 w-6" />
        </button>
        <div />

        <button
          type="button"
          aria-label="Move Left"
          onPointerDown={handleDirDown('LEFT')}
          className="flex items-center justify-center rounded-xl border border-slate-700/80 bg-slate-900/90 text-slate-100 shadow-inner active:scale-95 active:border-emerald-400/70 active:bg-emerald-500/25 active:text-emerald-200 cursor-pointer"
        >
          <ArrowLeft className="h-6 w-6" />
        </button>
        <div className="flex items-center justify-center rounded-lg bg-slate-900/50 border border-slate-800/80">
          <div className="h-2.5 w-2.5 rounded-full bg-emerald-400/50" />
        </div>
        <button
          type="button"
          aria-label="Move Right"
          onPointerDown={handleDirDown('RIGHT')}
          className="flex items-center justify-center rounded-xl border border-slate-700/80 bg-slate-900/90 text-slate-100 shadow-inner active:scale-95 active:border-emerald-400/70 active:bg-emerald-500/25 active:text-emerald-200 cursor-pointer"
        >
          <ArrowRight className="h-6 w-6" />
        </button>

        <div />
        <button
          type="button"
          aria-label="Move Down"
          onPointerDown={handleDirDown('DOWN')}
          className="flex items-center justify-center rounded-xl border border-slate-700/80 bg-slate-900/90 text-slate-100 shadow-inner active:scale-95 active:border-emerald-400/70 active:bg-emerald-500/25 active:text-emerald-200 cursor-pointer"
        >
          <ArrowDown className="h-6 w-6" />
        </button>
        <div />
      </div>

      {/* Hold-to-Boost Action Pad */}
      <div className="flex flex-col items-end gap-2">
        <button
          type="button"
          aria-label="Hold to Boost"
          onPointerDown={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onBoostChange(true);
          }}
          onPointerUp={() => onBoostChange(false)}
          onPointerCancel={() => onBoostChange(false)}
          onPointerLeave={() => onBoostChange(false)}
          className={`flex h-24 w-24 flex-col items-center justify-center gap-1 rounded-2xl border font-bold tracking-wider uppercase transition cursor-pointer ${
            isBoosting
              ? 'scale-95 border-sky-400 bg-sky-500/30 text-sky-200 shadow-[0_0_25px_rgba(56,189,248,0.45)]'
              : 'border-emerald-500/40 bg-slate-900/90 text-emerald-300 shadow-lg hover:border-emerald-400/60'
          }`}
        >
          <Zap className={`h-7 w-7 ${isBoosting ? 'fill-sky-300 text-sky-200' : 'text-emerald-400'}`} />
          <span className="text-[11px]">BOOST</span>
        </button>
        <span className="text-[10px] text-slate-500 tracking-wide">
          Swipe board or tap pad
        </span>
      </div>
    </div>
  );
};
