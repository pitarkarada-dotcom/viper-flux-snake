import {
  doesScoreQualify,
  getBestScore,
} from './leaderboard';
import { sound } from './sound';
import {
  Direction,
  EatRipple,
  FloatingPopup,
  FoodItem,
  GameMode,
  GamePhase,
  GridPos,
  HudSnapshot,
  Particle,
  Shockwave,
  SnakeSegment,
} from './types';

export const GRID_COLS = 21;
export const GRID_ROWS = 21;
const COMBO_WINDOW_MS = 4200;
const NOVA_DURATION_MS = 7500;
const MAX_COMBO = 8;

const OPPOSITE_DIR: Record<Direction, Direction> = {
  UP: 'DOWN',
  DOWN: 'UP',
  LEFT: 'RIGHT',
  RIGHT: 'LEFT',
};

const DIR_VEC: Record<Direction, GridPos> = {
  UP: { x: 0, y: -1 },
  DOWN: { x: 0, y: 1 },
  LEFT: { x: -1, y: 0 },
  RIGHT: { x: 1, y: 0 },
};

const DIR_SOUND_IDX: Record<Direction, number> = {
  UP: 0,
  RIGHT: 1,
  DOWN: 2,
  LEFT: 3,
};

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function haptic(pattern: number | number[]) {
  if (!sound.enabled) return;
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(pattern);
    }
  } catch {
    // ignore unsupported vibration environments
  }
}

export class SnakeGameEngine {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private rafId: number | null = null;
  private lastFrameTime = 0;

  // Game state
  public phase: GamePhase = 'menu';
  public mode: GameMode = 'arcade';
  private snake: SnakeSegment[] = [];
  private direction: Direction = 'RIGHT';
  private inputQueue: Direction[] = [];
  private pendingGrowth = 0;
  private foods: FoodItem[] = [];
  private nextFoodId = 1;

  // Timing & feel
  private tickAccumulator = 0;
  private currentTickMs = 108;
  private hitStopMs = 0;
  private elapsedPlayTimeMs = 0;
  private isBoosting = false;
  private boostStepCounter = 0;

  // Scoring & stats
  private score = 0;
  private bestScore = 0;
  private applesEaten = 0;
  private novasEaten = 0;
  private combo = 1;
  private maxCombo = 1;
  private comboTimerMs = 0;
  private deathReason: 'wall' | 'self' | null = null;
  private isNewRecord = false;
  private qualifiesForBoard = false;

  // Juice & VFX
  private particles: Particle[] = [];
  private shockwaves: Shockwave[] = [];
  private popups: FloatingPopup[] = [];
  private eatRipples: EatRipple[] = [];
  private shakeMagnitude = 0;
  private flashAlpha = 0;
  private flashColor = '#ffffff';
  private deathAnimProgress = 0;

  // Callbacks to React UI
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private onGameOverCallback: (snapshot: HudSnapshot) => void;
  private hudThrottleMs = 0;

  constructor(
    onHudUpdate: (snapshot: HudSnapshot) => void,
    onGameOverCallback: (snapshot: HudSnapshot) => void
  ) {
    this.onHudUpdate = onHudUpdate;
    this.onGameOverCallback = onGameOverCallback;
    this.bestScore = getBestScore();
    this.initAttractState();
  }

  public attachCanvas(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.resizeCanvas();
    this.startLoop();
    this.emitHud(true);
  }

  public detachCanvas() {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.canvas = null;
    this.ctx = null;
  }

  public resizeCanvas() {
    if (!this.canvas) return;
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    const width = Math.max(1, Math.floor(rect.width * dpr));
    const height = Math.max(1, Math.floor(rect.height * dpr));
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
  }

  public refreshBestScore() {
    this.bestScore = Math.max(this.bestScore, getBestScore());
    this.emitHud(true);
  }

  public setMode(mode: GameMode) {
    if (this.mode === mode) return;
    this.mode = mode;
    sound.playUiClick();
    if (this.phase === 'playing' || this.phase === 'paused' || this.phase === 'gameover') {
      this.startGame(mode);
    } else {
      this.emitHud(true);
    }
  }

  private initAttractState() {
    this.phase = 'menu';
    this.snake = [
      { x: 10, y: 10, prevX: 9, prevY: 10 },
      { x: 9, y: 10, prevX: 8, prevY: 10 },
      { x: 8, y: 10, prevX: 7, prevY: 10 },
      { x: 7, y: 10, prevX: 6, prevY: 10 },
      { x: 6, y: 10, prevX: 5, prevY: 10 },
    ];
    this.direction = 'RIGHT';
    this.inputQueue = [];
    this.foods = [];
    this.particles = [];
    this.shockwaves = [];
    this.popups = [];
    this.eatRipples = [];
    this.currentTickMs = 115;
    this.tickAccumulator = 0;
    this.spawnPulseFood({ x: 15, y: 10 });
  }

  public returnToMenu() {
    sound.playUiClick();
    this.isBoosting = false;
    this.initAttractState();
    this.emitHud(true);
  }

  public startGame(overrideMode?: GameMode, initialDir?: Direction) {
    sound.unlock();
    sound.playStart();

    if (overrideMode) {
      this.mode = overrideMode;
    }

    const startDir: Direction = initialDir || 'RIGHT';
    const sv = DIR_VEC[startDir];

    this.phase = 'playing';
    this.direction = startDir;
    this.inputQueue = [];
    this.pendingGrowth = 0;
    this.isBoosting = false;
    this.boostStepCounter = 0;

    // Symmetric 4-way launch position with 4 segments trailing behind startDir
    const cx = 10 - sv.x * 3;
    const cy = 10 - sv.y * 3;
    this.snake = [0, 1, 2, 3].map((k) => ({
      x: cx - sv.x * k,
      y: cy - sv.y * k,
      prevX: cx - sv.x * (k + 1),
      prevY: cy - sv.y * (k + 1),
    }));

    this.foods = [];
    this.particles = [];
    this.shockwaves = [];
    this.popups = [];
    this.eatRipples = [];

    this.score = 0;
    this.bestScore = getBestScore();
    this.applesEaten = 0;
    this.novasEaten = 0;
    this.combo = 1;
    this.maxCombo = 1;
    this.comboTimerMs = 0;
    this.elapsedPlayTimeMs = 0;
    this.deathReason = null;
    this.isNewRecord = false;
    this.qualifiesForBoard = false;
    this.deathAnimProgress = 0;
    this.hitStopMs = 0;
    this.shakeMagnitude = 0;
    this.flashAlpha = 0.14;
    this.flashColor = '#10b981';

    this.currentTickMs = this.computeBaseTickMs();
    this.tickAccumulator = 0;

    // First-10-seconds hook: place the very first orb 6 tiles directly ahead!
    this.spawnPulseFood({ x: cx + sv.x * 6, y: cy + sv.y * 6 });

    // Spawn subtle launch shockwave around head
    this.shockwaves.push({
      x: cx + 0.5,
      y: cy + 0.5,
      radius: 0.2,
      maxRadius: 3.2,
      color: '#34d399',
      life: 0,
      maxLife: 380,
      lineWidth: 2.5,
    });

    this.emitHud(true);
  }

  public togglePause() {
    if (this.phase === 'playing') {
      this.phase = 'paused';
      this.isBoosting = false;
      sound.playUiClick();
      this.emitHud(true);
    } else if (this.phase === 'paused') {
      this.phase = 'playing';
      this.lastFrameTime = performance.now();
      sound.playUiClick();
      this.emitHud(true);
    }
  }

  public setBoost(active: boolean) {
    if (this.phase !== 'playing') {
      this.isBoosting = false;
      return;
    }
    if (this.isBoosting !== active) {
      this.isBoosting = active;
      this.emitHud(true);
    }
  }

  public queueDirection(dir: Direction) {
    sound.unlock();

    if (this.phase === 'menu') {
      this.startGame(undefined, dir);
      return;
    }

    if (this.phase !== 'playing') {
      return;
    }

    const lastPlanned =
      this.inputQueue.length > 0
        ? this.inputQueue[this.inputQueue.length - 1]
        : this.direction;

    if (dir === lastPlanned || dir === OPPOSITE_DIR[lastPlanned]) {
      return;
    }

    if (this.inputQueue.length < 2) {
      this.inputQueue.push(dir);
      sound.playTurn(DIR_SOUND_IDX[dir]);
    }
  }

  private computeBaseTickMs(): number {
    // Starts crisp at 106ms (~9.4 tiles/sec), smoothly ramps down to 68ms as snake grows
    const extraSegments = Math.max(0, this.snake.length - 4);
    const speedReduction = Math.min(38, extraSegments * 1.15);
    return 106 - speedReduction;
  }

  private getEffectiveTickMs(): number {
    if (this.phase === 'menu') return 112;
    const base = this.computeBaseTickMs();
    return this.isBoosting ? Math.max(44, base * 0.56) : base;
  }

  private startLoop() {
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    this.lastFrameTime = performance.now();

    const frame = (now: number) => {
      const rawDt = now - this.lastFrameTime;
      this.lastFrameTime = now;
      const dt = Math.min(rawDt, 50); // clamp delta spike when tab returns

      this.update(dt);
      this.render();

      this.rafId = requestAnimationFrame(frame);
    };

    this.rafId = requestAnimationFrame(frame);
  }

  private update(dt: number) {
    // Always decay visual effects even during hit-stop or gameover
    this.updateVisualEffects(dt);

    if (this.phase === 'paused') {
      return;
    }

    if (this.phase === 'gameover') {
      this.deathAnimProgress = Math.min(1, this.deathAnimProgress + dt / 450);
      return;
    }

    if (this.hitStopMs > 0) {
      this.hitStopMs = Math.max(0, this.hitStopMs - dt);
      return;
    }

    if (this.phase === 'playing') {
      this.elapsedPlayTimeMs += dt;

      // Update combo decay timer
      if (this.comboTimerMs > 0) {
        this.comboTimerMs = Math.max(0, this.comboTimerMs - dt);
        if (this.comboTimerMs === 0 && this.combo > 1) {
          this.combo = 1;
          this.emitHud(true);
        }
      }

      // Check timed Nova expiration
      for (let i = this.foods.length - 1; i >= 0; i--) {
        const f = this.foods[i];
        if (f.kind === 'nova' && f.duration) {
          if (this.elapsedPlayTimeMs - f.spawnTime >= f.duration) {
            this.foods.splice(i, 1);
          }
        }
      }
    }

    this.currentTickMs = this.getEffectiveTickMs();
    this.tickAccumulator += dt;

    while (this.tickAccumulator >= this.currentTickMs) {
      this.tickAccumulator -= this.currentTickMs;
      if (this.phase === 'menu') {
        this.stepAttractAi();
      }
      this.stepSimulation();
      if (this.phase !== 'playing' && this.phase !== 'menu') {
        break;
      }
    }

    this.hudThrottleMs += dt;
    if (this.hudThrottleMs >= 65) {
      this.hudThrottleMs = 0;
      this.emitHud(false);
    }
  }

  private stepAttractAi() {
    const head = this.snake[0];
    const target = this.foods[0];
    if (!head || !target) return;

    const allDirs: Direction[] = ['UP', 'DOWN', 'LEFT', 'RIGHT'];
    const candidates = allDirs.filter(
      (d) => d !== OPPOSITE_DIR[this.direction]
    );

    let bestDir = this.direction;
    let bestDist = Infinity;

    for (const dir of candidates) {
      const v = DIR_VEC[dir];
      const nx = (head.x + v.x + GRID_COLS) % GRID_COLS;
      const ny = (head.y + v.y + GRID_ROWS) % GRID_ROWS;
      const hitsBody = this.snake.some(
        (seg, idx) => idx < this.snake.length - 1 && seg.x === nx && seg.y === ny
      );
      if (hitsBody) continue;
      const dx = Math.abs(nx - target.x);
      const dy = Math.abs(ny - target.y);
      const dist = dx + dy;
      if (dist < bestDist) {
        bestDist = dist;
        bestDir = dir;
      }
    }

    this.direction = bestDir;
  }

  private stepSimulation() {
    if (this.inputQueue.length > 0) {
      this.direction = this.inputQueue.shift()!;
    }

    const head = this.snake[0];
    const vec = DIR_VEC[this.direction];
    let nextX = head.x + vec.x;
    let nextY = head.y + vec.y;
    let didWarp = false;

    const activeMode: GameMode = this.phase === 'menu' ? 'warp' : this.mode;

    if (activeMode === 'arcade') {
      if (nextX < 0 || nextX >= GRID_COLS || nextY < 0 || nextY >= GRID_ROWS) {
        this.triggerGameOver('wall', head.x + 0.5 + vec.x * 0.4, head.y + 0.5 + vec.y * 0.4);
        return;
      }
    } else {
      if (nextX < 0) {
        nextX = GRID_COLS - 1;
        didWarp = true;
      } else if (nextX >= GRID_COLS) {
        nextX = 0;
        didWarp = true;
      }
      if (nextY < 0) {
        nextY = GRID_ROWS - 1;
        didWarp = true;
      } else if (nextY >= GRID_ROWS) {
        nextY = 0;
        didWarp = true;
      }
    }

    // Check self collision (tail vacates unless growing this step)
    const willGrow = this.pendingGrowth > 0;
    const checkLimit = willGrow ? this.snake.length : this.snake.length - 1;
    for (let i = 0; i < checkLimit; i++) {
      if (this.snake[i].x === nextX && this.snake[i].y === nextY) {
        if (this.phase === 'menu') {
          this.initAttractState();
          return;
        }
        this.triggerGameOver('self', nextX + 0.5, nextY + 0.5);
        return;
      }
    }

    // Save tail position in case we grow
    const lastSeg = this.snake[this.snake.length - 1];
    const savedTail = { x: lastSeg.x, y: lastSeg.y };

    // Shift body forward while storing prev coordinates for 60fps interpolation
    for (let i = this.snake.length - 1; i >= 1; i--) {
      this.snake[i].prevX = this.snake[i].x;
      this.snake[i].prevY = this.snake[i].y;
      this.snake[i].x = this.snake[i - 1].x;
      this.snake[i].y = this.snake[i - 1].y;
      this.snake[i].warped =
        Math.abs(this.snake[i].x - this.snake[i].prevX) > 1 ||
        Math.abs(this.snake[i].y - this.snake[i].prevY) > 1;
    }

    head.prevX = head.x;
    head.prevY = head.y;
    head.x = nextX;
    head.y = nextY;
    head.warped = didWarp;

    if (willGrow) {
      this.snake.push({
        x: savedTail.x,
        y: savedTail.y,
        prevX: savedTail.x,
        prevY: savedTail.y,
        warped: false,
      });
      this.pendingGrowth--;
    }

    // Warp visual + audio feedback
    if (didWarp && this.phase === 'playing') {
      sound.playWarp();
      this.spawnBurst(nextX + 0.5, nextY + 0.5, 10, '#38bdf8', 4.5);
    }

    // Boost exhaust particles + subtle bonus points
    if (this.phase === 'playing' && this.isBoosting) {
      const tail = this.snake[this.snake.length - 1];
      this.spawnBurst(tail.x + 0.5, tail.y + 0.5, 2, '#34d399', 2.2);
      this.boostStepCounter++;
      if (this.boostStepCounter % 3 === 0) {
        this.score += 1;
        sound.playBoostStep();
      }
    }

    // Check food pickup
    const eatenIndex = this.foods.findIndex((f) => f.x === nextX && f.y === nextY);
    if (eatenIndex !== -1) {
      const eaten = this.foods[eatenIndex];
      this.foods.splice(eatenIndex, 1);
      this.handleFoodEaten(eaten);
    }
  }

  private handleFoodEaten(food: FoodItem) {
    const cx = food.x + 0.5;
    const cy = food.y + 0.5;

    if (this.phase === 'menu') {
      // Keep attract snake sleek at max 9 segments
      if (this.snake.length < 9) {
        this.pendingGrowth += 1;
      }
      this.spawnBurst(cx, cy, 14, '#fb7185', 5.5);
      this.eatRipples.push({ progress: 0, color: '#34d399' });
      this.spawnPulseFood();
      return;
    }

    // Increment combo if timer active, else start at 1 (and immediately arm timer for next!)
    if (this.comboTimerMs > 0) {
      this.combo = Math.min(MAX_COMBO, this.combo + 1);
    } else {
      this.combo = 1;
    }
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    this.comboTimerMs = COMBO_WINDOW_MS;

    const boostMultiplier = this.isBoosting ? 1.5 : 1;

    if (food.kind === 'pulse') {
      this.applesEaten++;
      this.pendingGrowth += 1;
      const gained = Math.round(10 * this.combo * boostMultiplier);
      this.score += gained;

      sound.playEat(this.combo, this.isBoosting);
      haptic(12);
      this.shakeMagnitude = Math.min(9, 3.2 + this.combo * 0.7);
      this.eatRipples.push({ progress: 0, color: '#34d399' });

      this.spawnBurst(cx, cy, 16 + this.combo * 2, '#fb7185', 6.2);
      this.spawnBurst(cx, cy, 8, '#fda4af', 3.5);
      this.shockwaves.push({
        x: cx,
        y: cy,
        radius: 0.25,
        maxRadius: 2.3 + this.combo * 0.22,
        color: this.combo >= 4 ? '#f43f5e' : '#34d399',
        life: 0,
        maxLife: 320,
        lineWidth: 2.2,
      });

      this.popups.push({
        x: cx,
        y: cy - 0.25,
        vy: -1.8,
        text: `+${gained}`,
        subtext:
          this.combo > 1
            ? `x${this.combo} COMBO${this.isBoosting ? ' · BOOST' : ''}`
            : this.isBoosting
            ? 'FLUX BOOST'
            : undefined,
        color: this.combo >= 4 ? '#fda4af' : '#6ee7b7',
        life: 0,
        maxLife: 760,
        scale: 1 + Math.min(0.35, (this.combo - 1) * 0.06),
      });

      // Always keep 1 core Pulse Orb on the board
      this.spawnPulseFood();

      // Spawn a timed Golden Nova Super-Orb every 4 Pulse Orbs!
      if (this.applesEaten % 4 === 0 && !this.foods.some((f) => f.kind === 'nova')) {
        this.spawnNovaFood();
      }
    } else {
      // Golden Solar Nova Super-Orb!
      this.novasEaten++;
      this.pendingGrowth += 2;
      const gained = Math.round(50 * this.combo * boostMultiplier);
      this.score += gained;

      sound.playNova(this.combo);
      haptic([18, 25, 30]);
      this.hitStopMs = 36; // Crisp arcade impact freeze frame!
      this.shakeMagnitude = 11.5;
      this.flashAlpha = 0.2;
      this.flashColor = '#fbbf24';
      this.eatRipples.push({ progress: 0, color: '#fbbf24' });

      this.spawnBurst(cx, cy, 32, '#fbbf24', 8.5);
      this.spawnBurst(cx, cy, 14, '#fef08a', 5.0);
      this.shockwaves.push({
        x: cx,
        y: cy,
        radius: 0.3,
        maxRadius: 4.6,
        color: '#fbbf24',
        life: 0,
        maxLife: 460,
        lineWidth: 3.2,
      });

      this.popups.push({
        x: cx,
        y: cy - 0.35,
        vy: -2.1,
        text: `+${gained}`,
        subtext: `SOLAR NOVA x${this.combo}!`,
        color: '#fde047',
        life: 0,
        maxLife: 980,
        scale: 1.32,
      });
    }

    if (this.score > this.bestScore) {
      this.bestScore = this.score;
    }

    this.emitHud(true);
  }

  private findFreeCell(): GridPos | null {
    const occupied = new Set<string>();
    for (const s of this.snake) {
      occupied.add(`${s.x},${s.y}`);
    }
    for (const f of this.foods) {
      occupied.add(`${f.x},${f.y}`);
    }

    const free: GridPos[] = [];
    for (let y = 0; y < GRID_ROWS; y++) {
      for (let x = 0; x < GRID_COLS; x++) {
        // Slightly favor inner cells early on so new players don't get forced into corners immediately
        if (!occupied.has(`${x},${y}`)) {
          free.push({ x, y });
        }
      }
    }

    if (free.length === 0) return null;

    if (this.phase === 'playing' && this.applesEaten < 3) {
      const inner = free.filter(
        (p) => p.x >= 2 && p.x <= GRID_COLS - 3 && p.y >= 2 && p.y <= GRID_ROWS - 3
      );
      if (inner.length > 0) {
        return inner[Math.floor(Math.random() * inner.length)];
      }
    }

    return free[Math.floor(Math.random() * free.length)];
  }

  private spawnPulseFood(fixedPos?: GridPos) {
    const pos = fixedPos || this.findFreeCell();
    if (!pos) return;
    this.foods.push({
      id: this.nextFoodId++,
      x: pos.x,
      y: pos.y,
      kind: 'pulse',
      spawnTime: this.elapsedPlayTimeMs,
    });
  }

  private spawnNovaFood() {
    const pos = this.findFreeCell();
    if (!pos) return;
    this.foods.push({
      id: this.nextFoodId++,
      x: pos.x,
      y: pos.y,
      kind: 'nova',
      spawnTime: this.elapsedPlayTimeMs,
      duration: NOVA_DURATION_MS,
    });
    this.shockwaves.push({
      x: pos.x + 0.5,
      y: pos.y + 0.5,
      radius: 2.6,
      maxRadius: 0.4,
      color: '#fbbf24',
      life: 0,
      maxLife: 340,
      lineWidth: 2,
    });
  }

  private triggerGameOver(reason: 'wall' | 'self', crashX: number, crashY: number) {
    this.phase = 'gameover';
    this.isBoosting = false;
    this.deathReason = reason;
    this.deathAnimProgress = 0;
    this.shakeMagnitude = 15;
    this.flashAlpha = 0.34;
    this.flashColor = '#ef4444';

    const prevBest = getBestScore();
    this.isNewRecord = this.score > 0 && this.score > prevBest;
    this.qualifiesForBoard = doesScoreQualify(this.score);

    sound.playGameOver();
    haptic(45);
    if (this.isNewRecord) {
      sound.playNewHighScore();
    }

    // Burst shatter particles from crash site and along segments
    this.spawnBurst(crashX, crashY, 28, '#f43f5e', 8.5);
    this.spawnBurst(crashX, crashY, 14, '#fbbf24', 5.2);
    for (let i = 0; i < Math.min(this.snake.length, 24); i++) {
      const seg = this.snake[i];
      this.spawnBurst(seg.x + 0.5, seg.y + 0.5, 3, '#34d399', 3.4);
    }

    this.shockwaves.push({
      x: crashX,
      y: crashY,
      radius: 0.2,
      maxRadius: 5.2,
      color: '#f43f5e',
      life: 0,
      maxLife: 520,
      lineWidth: 3.5,
    });

    const snap = this.buildHudSnapshot();
    this.onHudUpdate(snap);
    this.onGameOverCallback(snap);
  }

  private spawnBurst(
    gx: number,
    gy: number,
    count: number,
    color: string,
    maxSpeed: number
  ) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.55;
      const speed = (0.3 + Math.random() * 0.7) * maxSpeed;
      this.particles.push({
        x: gx,
        y: gy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 0.08 + Math.random() * 0.14,
        color,
        alpha: 1,
        life: 0,
        maxLife: 320 + Math.random() * 340,
        glow: i % 2 === 0,
      });
    }
  }

  private updateVisualEffects(dt: number) {
    const dtSec = dt / 1000;

    if (this.shakeMagnitude > 0.05) {
      this.shakeMagnitude *= Math.pow(0.88, dt / 16.67);
    } else {
      this.shakeMagnitude = 0;
    }

    if (this.flashAlpha > 0.005) {
      this.flashAlpha *= Math.pow(0.86, dt / 16.67);
    } else {
      this.flashAlpha = 0;
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }
      p.x += p.vx * dtSec;
      p.y += p.vy * dtSec;
      p.vx *= Math.pow(0.92, dt / 16.67);
      p.vy *= Math.pow(0.92, dt / 16.67);
      p.alpha = 1 - p.life / p.maxLife;
    }

    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.life += dt;
      if (sw.life >= sw.maxLife) {
        this.shockwaves.splice(i, 1);
      }
    }

    for (let i = this.popups.length - 1; i >= 0; i--) {
      const pop = this.popups[i];
      pop.life += dt;
      if (pop.life >= pop.maxLife) {
        this.popups.splice(i, 1);
        continue;
      }
      pop.y += pop.vy * dtSec;
      pop.vy *= Math.pow(0.95, dt / 16.67);
    }

    for (let i = this.eatRipples.length - 1; i >= 0; i--) {
      const r = this.eatRipples[i];
      r.progress += dt / 360;
      if (r.progress >= 1) {
        this.eatRipples.splice(i, 1);
      }
    }
  }

  private buildHudSnapshot(): HudSnapshot {
    return {
      phase: this.phase,
      mode: this.mode,
      score: this.score,
      bestScore: this.bestScore,
      length: this.snake.length,
      combo: this.combo,
      maxCombo: this.maxCombo,
      comboProgress:
        this.comboTimerMs > 0 ? Math.min(1, this.comboTimerMs / COMBO_WINDOW_MS) : 0,
      isBoosting: this.isBoosting,
      applesEaten: this.applesEaten,
      novasEaten: this.novasEaten,
      survivalSeconds: Math.floor(this.elapsedPlayTimeMs / 1000),
      deathReason: this.deathReason,
      isNewRecord: this.isNewRecord,
      qualifiesForBoard: this.qualifiesForBoard,
    };
  }

  private emitHud(_immediate: boolean) {
    this.onHudUpdate(this.buildHudSnapshot());
  }

  // ==================== 60FPS CANVAS RENDERER ====================
  private render() {
    if (!this.ctx || !this.canvas) return;
    const ctx = this.ctx;
    const W = this.canvas.width;
    const H = this.canvas.height;
    const cellW = W / GRID_COLS;
    const cellH = H / GRID_ROWS;
    const cell = Math.min(cellW, cellH);
    const now = performance.now();

    const alpha =
      this.phase === 'gameover'
        ? 1
        : Math.max(0, Math.min(1, this.tickAccumulator / Math.max(1, this.currentTickMs)));

    ctx.save();

    // Base obsidian-cobalt surface
    const bgGrad = ctx.createRadialGradient(
      W * 0.5,
      H * 0.45,
      cell * 1.5,
      W * 0.5,
      H * 0.5,
      W * 0.8
    );
    bgGrad.addColorStop(0, '#0d1527');
    bgGrad.addColorStop(0.65, '#080d1a');
    bgGrad.addColorStop(1, '#050811');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // Apply camera screen shake
    if (this.shakeMagnitude > 0) {
      const sx = (Math.random() * 2 - 1) * this.shakeMagnitude * (cell / 28);
      const sy = (Math.random() * 2 - 1) * this.shakeMagnitude * (cell / 28);
      ctx.translate(sx, sy);
    }

    // Interpolate continuous segment positions with modular unwrapping across Warp boundaries
    const interpPoints: { x: number; y: number; warped: boolean }[] = this.snake.map((seg) => {
      let dx = seg.x - seg.prevX;
      if (dx > 1) dx -= GRID_COLS;
      else if (dx < -1) dx += GRID_COLS;

      let dy = seg.y - seg.prevY;
      if (dy > 1) dy -= GRID_ROWS;
      else if (dy < -1) dy += GRID_ROWS;

      const rawX = seg.prevX + dx * alpha + 0.5;
      const rawY = seg.prevY + dy * alpha + 0.5;
      const wrappedX = ((rawX % GRID_COLS) + GRID_COLS) % GRID_COLS;
      const wrappedY = ((rawY % GRID_ROWS) + GRID_ROWS) % GRID_ROWS;

      return {
        x: wrappedX,
        y: wrappedY,
        warped: Boolean(seg.warped),
      };
    });

    const headPt = interpPoints[0] || { x: 10.5, y: 10.5, warped: false };

    // 1. Subtle alternating checkerboard + illuminated grid intersections
    for (let y = 0; y < GRID_ROWS; y++) {
      for (let x = 0; x < GRID_COLS; x++) {
        if ((x + y) % 2 === 0) {
          ctx.fillStyle = 'rgba(148, 163, 184, 0.018)';
          ctx.fillRect(x * cellW, y * cellH, cellW, cellH);
        }
      }
    }

    // Ambient proximity glow pools under head & active foods
    this.drawRadialPool(
      ctx,
      headPt.x * cellW,
      headPt.y * cellH,
      cell * (this.isBoosting ? 4.4 : 3.2),
      this.isBoosting ? 'rgba(56, 189, 248, 0.14)' : 'rgba(16, 185, 129, 0.12)'
    );

    for (const f of this.foods) {
      const fx = (f.x + 0.5) * cellW;
      const fy = (f.y + 0.5) * cellH;
      if (f.kind === 'pulse') {
        this.drawRadialPool(ctx, fx, fy, cell * 3.1, 'rgba(244, 63, 94, 0.14)');
      } else {
        this.drawRadialPool(ctx, fx, fy, cell * 3.8, 'rgba(251, 191, 36, 0.19)');
      }
    }

    // Crisp subtle grid lines
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.055)';
    ctx.lineWidth = Math.max(1, cell * 0.025);
    ctx.beginPath();
    for (let x = 1; x < GRID_COLS; x++) {
      const px = Math.round(x * cellW) + 0.5;
      ctx.moveTo(px, 0);
      ctx.lineTo(px, H);
    }
    for (let y = 1; y < GRID_ROWS; y++) {
      const py = Math.round(y * cellH) + 0.5;
      ctx.moveTo(0, py);
      ctx.lineTo(W, py);
    }
    ctx.stroke();

    // Perimeter border cue: solid crimson-amber hazard glow when close in Arcade mode, or dashed cyan portal in Warp mode
    this.renderArenaBorder(ctx, W, H, cell, headPt);

    // 2. Shockwaves
    for (const sw of this.shockwaves) {
      const t = sw.life / sw.maxLife;
      const ease = 1 - Math.pow(1 - t, 3);
      const r = lerp(sw.radius, sw.maxRadius, ease) * cell;
      ctx.save();
      ctx.globalAlpha = Math.max(0, 1 - t) * 0.85;
      ctx.strokeStyle = sw.color;
      ctx.lineWidth = sw.lineWidth * (1 - t * 0.5) * (cell / 24);
      ctx.beginPath();
      ctx.arc(sw.x * cellW, sw.y * cellH, Math.max(1, r), 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 3. Food Orbs (Pulse Apple + Solar Nova)
    for (const f of this.foods) {
      this.renderFoodItem(ctx, f, cellW, cellH, cell, now);
    }

    // 4. Snake Spine, Scales & Expressive Head
    if (interpPoints.length > 0) {
      this.renderSnake(ctx, interpPoints, cellW, cellH, cell, now);
    }

    // 5. Particles
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.fillStyle = p.color;
      if (p.glow) {
        ctx.shadowColor = p.color;
        ctx.shadowBlur = cell * 0.45;
      }
      const pr = Math.max(1.2, p.size * cell * (0.4 + p.alpha * 0.6));
      ctx.beginPath();
      ctx.arc(p.x * cellW, p.y * cellH, pr, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 6. Floating Score Popups
    for (const pop of this.popups) {
      const t = pop.life / pop.maxLife;
      const fade = t < 0.7 ? 1 : 1 - (t - 0.7) / 0.3;
      const popScale = pop.scale * (t < 0.14 ? lerp(0.65, 1.08, t / 0.14) : 1);
      const px = Math.min(W - cell * 2.2, Math.max(cell * 2.2, pop.x * cellW));
      const py = Math.max(cell * 1.4, pop.y * cellH);

      ctx.save();
      ctx.globalAlpha = Math.max(0, fade);
      ctx.translate(px, py);
      ctx.scale(popScale, popScale);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      ctx.font = `800 ${Math.round(cell * 0.62)}px "JetBrains Mono", monospace`;
      ctx.fillStyle = '#040711';
      ctx.fillText(pop.text, 0, 2);
      ctx.fillStyle = pop.color;
      ctx.shadowColor = pop.color;
      ctx.shadowBlur = 10;
      ctx.fillText(pop.text, 0, 0);

      if (pop.subtext) {
        ctx.shadowBlur = 4;
        ctx.font = `700 ${Math.round(cell * 0.31)}px "Space Grotesk", sans-serif`;
        ctx.fillStyle = '#f8fafc';
        ctx.fillText(pop.subtext, 0, cell * 0.52);
      }
      ctx.restore();
    }

    // 7. Impact Flash Overlay
    if (this.flashAlpha > 0.005) {
      ctx.fillStyle = this.flashColor;
      ctx.globalAlpha = this.flashAlpha;
      ctx.fillRect(-cell, -cell, W + cell * 2, H + cell * 2);
      ctx.globalAlpha = 1;
    }

    ctx.restore();
  }

  private drawRadialPool(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number,
    innerColor: string
  ) {
    const grad = ctx.createRadialGradient(x, y, 0, x, y, radius);
    grad.addColorStop(0, innerColor);
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
  }

  private renderArenaBorder(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    cell: number,
    headPt: { x: number; y: number }
  ) {
    const activeMode: GameMode = this.phase === 'menu' ? 'warp' : this.mode;
    ctx.save();

    if (activeMode === 'arcade') {
      // Subtle solid perimeter rail + dynamic danger proximity pulse when head is <= 2 tiles from wall
      const minEdgeDist = Math.min(
        headPt.x - 0.5,
        GRID_COLS - 0.5 - headPt.x,
        headPt.y - 0.5,
        GRID_ROWS - 0.5 - headPt.y
      );
      const danger = this.phase === 'playing' ? Math.max(0, 1 - minEdgeDist / 2.5) : 0;

      ctx.strokeStyle =
        danger > 0.1
          ? `rgba(244, 63, 94, ${0.28 + danger * 0.55})`
          : 'rgba(52, 211, 153, 0.22)';
      ctx.lineWidth = Math.max(2, cell * (0.09 + danger * 0.07));
      ctx.strokeRect(1, 1, W - 2, H - 2);
    } else {
      // Dashed electric cyan warp border
      ctx.setLineDash([cell * 0.45, cell * 0.35]);
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.38)';
      ctx.lineWidth = Math.max(2, cell * 0.08);
      ctx.strokeRect(1, 1, W - 2, H - 2);
    }

    ctx.restore();
  }

  private renderFoodItem(
    ctx: CanvasRenderingContext2D,
    food: FoodItem,
    cellW: number,
    cellH: number,
    cell: number,
    now: number
  ) {
    const cx = (food.x + 0.5) * cellW;
    const cy = (food.y + 0.5) * cellH;
    const pulse = Math.sin(now * 0.0065) * 0.075;

    ctx.save();

    if (food.kind === 'pulse') {
      // If combo window is active, render clean shrinking combo timer ring directly around the food!
      if (this.phase === 'playing' && this.comboTimerMs > 0) {
        const progress = this.comboTimerMs / COMBO_WINDOW_MS;
        ctx.beginPath();
        ctx.strokeStyle = this.combo >= 3 ? 'rgba(251, 191, 36, 0.72)' : 'rgba(52, 211, 153, 0.58)';
        ctx.lineWidth = Math.max(1.8, cell * 0.075);
        ctx.arc(
          cx,
          cy,
          cell * 0.54,
          -Math.PI / 2,
          -Math.PI / 2 + Math.PI * 2 * progress
        );
        ctx.stroke();
      }

      const r = cell * (0.35 + pulse);
      ctx.shadowColor = '#f43f5e';
      ctx.shadowBlur = cell * 0.65;

      const grad = ctx.createRadialGradient(
        cx - r * 0.28,
        cy - r * 0.28,
        r * 0.12,
        cx,
        cy,
        r
      );
      grad.addColorStop(0, '#ffe4e6');
      grad.addColorStop(0.35, '#fb7185');
      grad.addColorStop(1, '#e11d48');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      // Crisp emerald leaf accent on top so it reads unmistakably as a juicy cyber-apple
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#34d399';
      ctx.beginPath();
      ctx.ellipse(
        cx + r * 0.22,
        cy - r * 0.82,
        r * 0.34,
        r * 0.17,
        -Math.PI / 5,
        0,
        Math.PI * 2
      );
      ctx.fill();
    } else {
      // Golden Solar Nova Super-Orb with countdown ring & rotating diamond star
      const elapsed = this.elapsedPlayTimeMs - food.spawnTime;
      const remain = food.duration ? Math.max(0, 1 - elapsed / food.duration) : 1;
      const blink = remain < 0.28 ? 0.55 + 0.45 * Math.sin(now * 0.03) : 1;

      ctx.globalAlpha = blink;

      // Countdown fuse arc
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.85)';
      ctx.lineWidth = Math.max(2, cell * 0.085);
      ctx.arc(
        cx,
        cy,
        cell * 0.58,
        -Math.PI / 2,
        -Math.PI / 2 + Math.PI * 2 * remain
      );
      ctx.stroke();

      // Rotating star core
      const r = cell * (0.4 + Math.sin(now * 0.01) * 0.06);
      ctx.translate(cx, cy);
      ctx.rotate(now * 0.0022);
      ctx.shadowColor = '#f59e0b';
      ctx.shadowBlur = cell * 0.85;

      const nGrad = ctx.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
      nGrad.addColorStop(0, '#ffffff');
      nGrad.addColorStop(0.42, '#fde047');
      nGrad.addColorStop(1, '#d97706');
      ctx.fillStyle = nGrad;

      ctx.beginPath();
      const spikes = 4;
      for (let i = 0; i < spikes * 2; i++) {
        const rad = i % 2 === 0 ? r * 1.15 : r * 0.55;
        const ang = (i * Math.PI) / spikes;
        if (i === 0) ctx.moveTo(Math.cos(ang) * rad, Math.sin(ang) * rad);
        else ctx.lineTo(Math.cos(ang) * rad, Math.sin(ang) * rad);
      }
      ctx.closePath();
      ctx.fill();
    }

    ctx.restore();
  }

  private renderSnake(
    ctx: CanvasRenderingContext2D,
    pts: { x: number; y: number; warped: boolean }[],
    cellW: number,
    cellH: number,
    cell: number,
    now: number
  ) {
    const len = pts.length;
    const isDead = this.phase === 'gameover';

    ctx.save();
    if (isDead) {
      ctx.globalAlpha = Math.max(0.32, 1 - this.deathAnimProgress * 0.55);
    }

    // Draw continuous rounded body connectors back-to-front so head sits cleanly on top
    for (let i = len - 1; i >= 0; i--) {
      const pt = pts[i];
      const t = len > 1 ? i / (len - 1) : 0; // 0 = head, 1 = tail

      // Compute ripple bulge from recently eaten orbs
      let rippleBulge = 0;
      let rippleTint: string | null = null;
      for (const rip of this.eatRipples) {
        const dist = Math.abs(t - rip.progress);
        if (dist < 0.18) {
          const strength = 1 - dist / 0.18;
          if (strength > rippleBulge) {
            rippleBulge = strength;
            rippleTint = rip.color;
          }
        }
      }

      const baseRadius = cell * lerp(0.44, 0.25, Math.pow(t, 1.25));
      const radius = baseRadius * (1 + rippleBulge * 0.26);

      const px = pt.x * cellW;
      const py = pt.y * cellH;

      // Color gradient along body: luminous emerald -> teal -> cyan tail
      let bodyColor: string;
      if (isDead) {
        bodyColor = i === 0 ? '#f87171' : '#ef4444';
      } else if (rippleTint && rippleBulge > 0.45) {
        bodyColor = rippleTint;
      } else if (this.isBoosting) {
        bodyColor = i % 2 === 0 ? '#2dd4bf' : '#38bdf8';
      } else {
        const r = Math.round(lerp(16, 14, t));
        const g = Math.round(lerp(215, 155, t));
        const b = Math.round(lerp(135, 195, t));
        bodyColor = `rgb(${r}, ${g}, ${b})`;
      }

      // Draw C1-smooth quadratic Bezier capsule through the corner pivot between segment i and i-1
      if (i > 0) {
        const prev = pts[i - 1];
        const seg = this.snake[i];
        const pivotX = seg.x + 0.5;
        const pivotY = seg.y + 0.5;
        const d1 = Math.hypot(pivotX - pt.x, pivotY - pt.y);
        const d2 = Math.hypot(prev.x - pivotX, prev.y - pivotY);

        if (d1 < 1.5 && d2 < 1.5) {
          ctx.strokeStyle = bodyColor;
          ctx.lineWidth = radius * 2;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.quadraticCurveTo(
            pivotX * cellW,
            pivotY * cellH,
            prev.x * cellW,
            prev.y * cellH
          );
          ctx.stroke();
        }
      }

      // Draw segment node + dorsal highlight dot
      ctx.fillStyle = bodyColor;
      ctx.beginPath();
      ctx.arc(px, py, radius, 0, Math.PI * 2);
      ctx.fill();

      if (i > 0 && i < len - 1 && !isDead) {
        ctx.fillStyle = 'rgba(236, 253, 245, 0.28)';
        ctx.beginPath();
        ctx.arc(px, py, radius * 0.34, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Render expressive Viper Head at pts[0]
    const head = pts[0];
    const hx = head.x * cellW;
    const hy = head.y * cellH;
    const lookDir = this.inputQueue.length > 0 ? this.inputQueue[0] : this.direction;

    let angle = 0;
    if (lookDir === 'RIGHT') angle = 0;
    else if (lookDir === 'DOWN') angle = Math.PI / 2;
    else if (lookDir === 'LEFT') angle = Math.PI;
    else if (lookDir === 'UP') angle = -Math.PI / 2;

    ctx.save();
    ctx.translate(hx, hy);
    ctx.rotate(angle);

    // Subtle forked cyber-tongue flick when near food
    const nearFood = this.foods.some(
      (f) => Math.hypot(f.x + 0.5 - head.x, f.y + 0.5 - head.y) < 5.5
    );
    if (!isDead && (nearFood || Math.sin(now * 0.008) > 0.65)) {
      const flick = 0.72 + 0.28 * Math.sin(now * 0.035);
      ctx.strokeStyle = '#fb7185';
      ctx.lineWidth = Math.max(1.5, cell * 0.07);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(cell * 0.38, 0);
      ctx.lineTo(cell * (0.38 + 0.24 * flick), 0);
      ctx.lineTo(cell * (0.38 + 0.35 * flick), -cell * 0.11);
      ctx.moveTo(cell * (0.38 + 0.24 * flick), 0);
      ctx.lineTo(cell * (0.38 + 0.35 * flick), cell * 0.11);
      ctx.stroke();
    }

    // Head shield shape
    const headR = cell * 0.48;
    ctx.shadowColor = isDead ? '#ef4444' : this.isBoosting ? '#38bdf8' : '#10b981';
    ctx.shadowBlur = cell * 0.55;
    ctx.fillStyle = isDead ? '#f87171' : this.isBoosting ? '#5eead4' : '#34d399';
    ctx.beginPath();
    ctx.ellipse(cell * 0.04, 0, headR * 1.08, headR * 0.94, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Crisp glowing eyes looking slightly forward
    const eyeX = cell * 0.15;
    const eyeY = cell * 0.22;
    const eyeR = cell * 0.115;

    ctx.fillStyle = '#040711';
    ctx.beginPath();
    ctx.arc(eyeX, -eyeY, eyeR * 1.25, 0, Math.PI * 2);
    ctx.arc(eyeX, eyeY, eyeR * 1.25, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = isDead ? '#fca5a5' : '#ffffff';
    ctx.beginPath();
    ctx.arc(eyeX + eyeR * 0.28, -eyeY, eyeR * 0.62, 0, Math.PI * 2);
    ctx.arc(eyeX + eyeR * 0.28, eyeY, eyeR * 0.62, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
    ctx.restore();
  }
}
