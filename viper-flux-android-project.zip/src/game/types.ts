export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export type GameMode = 'arcade' | 'warp';

export type GamePhase = 'menu' | 'playing' | 'paused' | 'gameover';

export interface GridPos {
  x: number;
  y: number;
}

export interface SnakeSegment {
  prevX: number;
  prevY: number;
  x: number;
  y: number;
  warped?: boolean;
}

export interface FoodItem {
  id: number;
  x: number;
  y: number;
  kind: 'pulse' | 'nova';
  spawnTime: number;
  duration?: number; // ms for timed nova super-orb
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  glow?: boolean;
}

export interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  life: number;
  maxLife: number;
  lineWidth: number;
}

export interface FloatingPopup {
  x: number;
  y: number;
  vy: number;
  text: string;
  subtext?: string;
  color: string;
  life: number;
  maxLife: number;
  scale: number;
}

export interface EatRipple {
  progress: number; // 0 (head) -> 1 (tail)
  color: string;
}

export interface HighScoreEntry {
  id: string;
  name: string;
  score: number;
  length: number;
  maxCombo: number;
  mode: GameMode;
  date: string;
  isPlayer?: boolean;
}

export interface HudSnapshot {
  phase: GamePhase;
  mode: GameMode;
  score: number;
  bestScore: number;
  length: number;
  combo: number;
  maxCombo: number;
  comboProgress: number; // 0..1 remaining time before combo resets
  isBoosting: boolean;
  applesEaten: number;
  novasEaten: number;
  survivalSeconds: number;
  deathReason: 'wall' | 'self' | null;
  isNewRecord: boolean;
  qualifiesForBoard: boolean;
}
