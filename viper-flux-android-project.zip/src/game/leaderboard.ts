import { GameMode, HighScoreEntry } from './types';

const LEADERBOARD_KEY = 'viper_flux_highscores_v1';
const PLAYER_NAME_KEY = 'viper_flux_player_name_v1';
export const MAX_LEADERBOARD_ENTRIES = 8;

const DEFAULT_RIVALS: HighScoreEntry[] = [
  {
    id: 'rival-1',
    name: 'KAI-9',
    score: 860,
    length: 34,
    maxCombo: 6,
    mode: 'arcade',
    date: 'ARCADE',
  },
  {
    id: 'rival-2',
    name: 'NOVA',
    score: 640,
    length: 27,
    maxCombo: 5,
    mode: 'warp',
    date: 'ARCADE',
  },
  {
    id: 'rival-3',
    name: 'VEX',
    score: 450,
    length: 20,
    maxCombo: 4,
    mode: 'arcade',
    date: 'ARCADE',
  },
  {
    id: 'rival-4',
    name: 'SYNTH',
    score: 290,
    length: 15,
    maxCombo: 3,
    mode: 'arcade',
    date: 'ARCADE',
  },
  {
    id: 'rival-5',
    name: 'ECHO',
    score: 160,
    length: 10,
    maxCombo: 2,
    mode: 'warp',
    date: 'ARCADE',
  },
];

export function loadLeaderboard(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem(LEADERBOARD_KEY);
    if (!raw) {
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(DEFAULT_RIVALS));
      return [...DEFAULT_RIVALS];
    }
    const parsed = JSON.parse(raw) as HighScoreEntry[];
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return [...DEFAULT_RIVALS];
    }
    return parsed
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX_LEADERBOARD_ENTRIES);
  } catch {
    return [...DEFAULT_RIVALS];
  }
}

export function saveLeaderboard(entries: HighScoreEntry[]): HighScoreEntry[] {
  const sorted = [...entries]
    .sort((a, b) => b.score - a.score)
    .slice(0, MAX_LEADERBOARD_ENTRIES);
  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(sorted));
  } catch {
    // ignore storage errors
  }
  return sorted;
}

export function getSavedPlayerName(): string {
  try {
    return localStorage.getItem(PLAYER_NAME_KEY) || 'VIPER';
  } catch {
    return 'VIPER';
  }
}

export function savePlayerName(name: string): string {
  const cleaned = name.trim().toUpperCase().slice(0, 10) || 'VIPER';
  try {
    localStorage.setItem(PLAYER_NAME_KEY, cleaned);
  } catch {
    // ignore
  }
  return cleaned;
}

export function getBestScore(): number {
  const entries = loadLeaderboard();
  return entries.length > 0 ? entries[0].score : 0;
}

export function doesScoreQualify(score: number): boolean {
  if (score <= 0) return false;
  const entries = loadLeaderboard();
  if (entries.length < MAX_LEADERBOARD_ENTRIES) return true;
  return score > entries[entries.length - 1].score;
}

export function recordScore(params: {
  name: string;
  score: number;
  length: number;
  maxCombo: number;
  mode: GameMode;
}): { entries: HighScoreEntry[]; createdEntry: HighScoreEntry | null } {
  if (params.score <= 0 || !doesScoreQualify(params.score)) {
    return { entries: loadLeaderboard(), createdEntry: null };
  }

  const now = new Date();
  const dateLabel = now.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
  });

  const entry: HighScoreEntry = {
    id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name: savePlayerName(params.name),
    score: params.score,
    length: params.length,
    maxCombo: params.maxCombo,
    mode: params.mode,
    date: dateLabel,
    isPlayer: true,
  };

  const current = loadLeaderboard();
  const updated = saveLeaderboard([...current, entry]);
  const kept = updated.find((e) => e.id === entry.id) || null;
  return { entries: updated, createdEntry: kept };
}

export function renameScoreEntry(entryId: string, newName: string): HighScoreEntry[] {
  const cleaned = savePlayerName(newName);
  const current = loadLeaderboard();
  const updated = current.map((item) =>
    item.id === entryId ? { ...item, name: cleaned } : item
  );
  return saveLeaderboard(updated);
}

export function resetLeaderboard(): HighScoreEntry[] {
  return saveLeaderboard([...DEFAULT_RIVALS]);
}
