# VIPER FLUX Snake — Android app project

This wraps your existing React/Vite Snake game as an Android app using Capacitor. Game files are bundled locally, and Google Fonts network links are removed so gameplay does not depend on internet access. Scores/settings are stored locally.

## Requirements
- Node.js 20+ recommended
- Android Studio with Android SDK installed

## Build the APK (on a computer)
1. Extract this ZIP and open a terminal in this folder.
2. Run:

```bash
npm install
npx cap add android
npm run cap:sync
npx cap open android
```

If `android/` already exists, skip `npx cap add android`. In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the resulting APK path. To test directly, connect an Android phone with USB debugging enabled and press Run.

## App details
- Name: VIPER FLUX Snake
- Application ID: `com.viperflux.snake`
- Web app assets are packaged inside the app; no website connection is needed to play.
- Existing touch controls and localStorage score/settings are retained.

**Note:** This ZIP contains the app-ready source/configuration, not a prebuilt APK. Building an APK requires Android SDK/Gradle tooling, normally through Android Studio.
